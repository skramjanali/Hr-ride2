# HR RIDE v12 — Firebase OTP Ready

The project now includes:
- Firebase Core initialization
- Firebase Phone Authentication service
- OTP login screen wired as the app entry
- Android package: com.hrride.app
- google-services.json in android/app
- Android Google Services Gradle plugin
- Internet permission

On a computer with Flutter installed:
1. unzip the project
2. run `flutter pub get`
3. run `flutter run`

Firebase Console:
Authentication > Sign-in method > Phone = Enabled.

For Android release/testing, add your app's SHA-1 and SHA-256 in:
Project settings > Your apps > Android app.

Important: Firebase OTP is real, but the app is not automatically published to Play Store/App Store and no production payment/maps backend has been deployed by this package.
