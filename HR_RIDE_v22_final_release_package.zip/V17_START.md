# HR RIDE V17 — Full Ride Flow

Added:
- Customer creates a real Firestore ride request.
- Driver online mode receives Firestore ride requests.
- Driver accepts a request atomically (first driver wins).
- Customer immediately sees assigned driver and status.
- Customer can cancel active rides.
- Driver GPS continues updating while online.
- Live tracking screen remains available.
- Admin reads live driver/ride data.

Firebase project: `hr-ride`
Android package: `com.hrride.app`

Before production: deploy Firestore rules, configure FCM/APNs, use a secure HTTPS backend, and implement server-side notification dispatch and payment verification. The included payment service must never contain a Razorpay secret.
