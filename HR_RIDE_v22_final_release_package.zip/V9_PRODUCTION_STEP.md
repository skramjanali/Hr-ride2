# HR RIDE v9 — Production Step

Added production-oriented service scaffolding:
- OTP service abstraction
- AC / Non-AC fare service
- Ride status state machine
- Notification service abstraction
- Payment service abstraction
- Production configuration via `--dart-define`

Live integrations are intentionally not faked. Real OTP, GPS/maps, notifications,
payments and backend require provider credentials and deployment.

Suggested release build variables:
MAPS_API_KEY
BACKEND_URL
FIREBASE_PROJECT_ID
PAYMENT_KEY
