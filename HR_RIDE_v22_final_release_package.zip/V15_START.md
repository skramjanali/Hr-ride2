
# HR RIDE V15 — Firebase Realtime + Notifications + Payment

Based on V14.

### Added
- Cloud Firestore ride/driver persistence and real-time streams
- Firebase Cloud Messaging (FCM) token + ride topic scaffolding
- Razorpay Flutter checkout integration
- Server-side Razorpay order creation endpoint
- Server-side Razorpay payment signature verification endpoint
- Firestore security rules starter

### Firebase
Enable **Cloud Firestore** and **Cloud Messaging** in the `hr-ride` Firebase project.
Do not put Firebase Admin private keys in the Flutter app.

### Razorpay
Set these environment variables on the backend only:
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`

The Flutter app must receive a server-created `order_id`. Never ship `RAZORPAY_KEY_SECRET` in the app.

### Payment flow
1. App asks backend to create an order.
2. Backend calls Razorpay Orders API.
3. App opens Razorpay checkout using public key ID + order ID.
4. App sends payment ID/order ID/signature to backend.
5. Backend verifies the signature.
6. Only after verification should the ride/payment be marked paid.

Razorpay's current Flutter package is `razorpay_flutter 1.4.6`; its checkout is Android/iOS.
