# HR RIDE v8

Upgraded from v7.

## Included
- Demo mobile login + OTP verification flow
- AC / Non-AC fare selector
- Fare calculation: AC ₹17/km, Non-AC ₹15/km
- Distance-based fare estimate
- Ride cancellation flow
- Customer ride history (local demo)
- Expanded driver ride lifecycle
- Updated launcher/version label

## Important
This is still a development/demo build. Real OTP/SMS, GPS/live maps, online payments,
push notifications, production backend, and store publishing require service credentials
and deployment configuration.
