# HR RIDE Production Checklist

## Backend
- Firebase Auth / OTP
- Firestore or PostgreSQL
- Driver/customer profiles
- Ride state machine
- Real-time driver location
- Admin roles and audit logs

## Maps
- Maps SDK for Android
- Maps SDK for iOS
- Places/autocomplete
- Directions/ETA
- Location permission flows

## Payments
- Select an India-supported payment gateway
- Server-side payment verification
- Cash/UPI/card states
- Refund handling

## Notifications
- Push notification service
- Ride request / acceptance / arrival / completion notifications

## Release
- Android signing key + Play Console
- Apple Developer account + certificates
- Privacy policy, terms, cancellation policy
- Production environment variables
