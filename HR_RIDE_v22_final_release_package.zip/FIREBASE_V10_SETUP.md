# HR RIDE v10 — Firebase Android Integration

The supplied Firebase Android configuration is installed at:
`android/app/google-services.json`

Firebase project: `hr-ride`
Android package: `com.hrride.app`

Integrated:
- Firebase Core initialization
- Firebase Auth dependency
- Firebase Phone Auth service

Before running:
1. `flutter pub get`
2. Enable Authentication > Phone in Firebase Console.
3. Add Android SHA-1/SHA-256 fingerprints if required by Firebase verification.
4. Test OTP with a real phone number.

This does not claim that SMS OTP is live until Phone Authentication is enabled in the
Firebase project. Payment secrets must never be placed in the Flutter client.
