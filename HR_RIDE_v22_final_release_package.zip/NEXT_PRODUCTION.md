# HR RIDE — Next Production Steps

The app now has a clean configuration layer and a REST backend service interface.

Run with:
flutter pub get

Production values can be supplied without hard-coding secrets:
flutter run --dart-define=MAPS_API_KEY=YOUR_KEY --dart-define=BACKEND_URL=https://your-api.example

Before release:
1. Configure Google Maps for Android/iOS.
2. Build a secure backend and database.
3. Add OTP authentication.
4. Add real-time driver location.
5. Add server-side fare calculation.
6. Add payment gateway and webhook verification.
7. Configure push notifications.
8. Test permissions, cancellations, refunds and driver verification.
9. Configure Android/iOS signing and store metadata.
