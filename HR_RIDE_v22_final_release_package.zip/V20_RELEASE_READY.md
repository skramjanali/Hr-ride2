# HR RIDE V20 — Release Ready

This package is the next release-ready scaffold for HR RIDE.

## Release flow
Customer:
Book → Requested → Driver Assigned → Arriving → Started → Completed

Driver:
Online → Accept → Arriving → Start Ride → Complete

## Production checklist
1. Firebase Phone Authentication enabled.
2. Firestore rules reviewed and deployed.
3. Google Maps API key restricted to the Android/iOS apps.
4. Routes API enabled if route/ETA features are used.
5. FCM server-side notification sender deployed with Firebase Admin/Cloud Functions.
6. Razorpay orders created and signatures verified only on the server.
7. Replace any development HTTP backend URL with a deployed HTTPS backend.
8. Build Android App Bundle (`flutter build appbundle --release`).
9. Configure iOS signing and App Store provisioning on macOS/Xcode.
10. Test customer, driver, cancellation, GPS, notification and payment flows on physical devices.

## Important
This package is source code/scaffolding. It does not deploy Firebase, a backend, Razorpay, Google Cloud, Play Store, or App Store automatically, and it does not contain private API/payment secrets.


## V21
Production integration checklist added; private credentials remain external.
