# HR RIDE — Start Here

1. Flutter app is under the root project.
2. Backend demo is under `backend/`.
3. Run `npm install` and `npm start` inside `backend/`.
4. Run Flutter with:
   `flutter pub get`
5. Connect the app to your deployed backend using:
   `--dart-define=BACKEND_URL=https://your-domain.example`

This package is a development base, not a claim that a live production
ride service has been deployed.
