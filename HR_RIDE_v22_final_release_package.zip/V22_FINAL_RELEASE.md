# HR RIDE V22 — Final Release Package

V22 is the final release-preparation package built on V21.

## App flow
Customer:
Login/OTP -> AC/Non-AC -> booking -> requested -> assigned -> live tracking -> complete -> payment

Driver:
Login -> Online -> GPS -> requested rides -> Accept -> Arriving -> Start -> Complete -> Offline

Admin:
Live driver count -> active ride monitoring -> ride status visibility

## Production configuration
Before publishing:
- Firebase Phone Authentication: enabled and tested
- Firestore security rules: reviewed and deployed
- FCM: production sender/Cloud Functions configured
- Google Maps Android/iOS SDK: enabled with restricted keys
- Routes API: enable if route/ETA is used
- HTTPS backend: deployed and configured in BACKEND_BASE_URL
- Razorpay: server-side order creation + signature verification
- Android signing / release keystore
- iOS signing and provisioning on macOS/Xcode

## Security
Do not commit:
- Razorpay key secret
- Firebase service-account private key
- unrestricted Google API keys

## Fare
AC: ₹17/km, minimum 200 km
Non-AC: ₹15/km, minimum 200 km
Toll tax and parking are separate.
Driver charge: not applicable.

## Release testing
Test on physical Android and iPhone devices:
1. OTP login
2. Location permission
3. Customer creates ride
4. Driver receives request
5. First driver accepts
6. Customer sees driver/status
7. Driver Arriving -> Start -> Complete
8. Live GPS updates
9. Cancellation rules
10. Payment success/failure
11. Notification delivery
12. App restart/reconnect
13. Firestore rules block unauthorized writes
14. Backend HTTPS only

## Important
This is a release-ready source package, not a claim of store publication or cloud deployment. Account-side deployment and signing must still be completed.
