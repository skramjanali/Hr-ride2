# HR RIDE v3
Android + iPhone Flutter starter.

Added:
- Customer app entry
- Driver dashboard with online/offline and demo ride request
- Admin dashboard with customers, drivers, rides and revenue cards
- HR RIDE generated logo asset
- Existing customer booking/fare/history/wallet/profile UI

Still needed for a real live service:
- Backend/database
- OTP/authentication
- Google Maps/GPS and routing
- Real-time driver location
- Payment gateway
- Push notifications
- Driver/customer verification workflows
- Production signing and store configuration


V13 adds Google Maps + device GPS tracking screen. See V13_MAPS_GPS.md.
