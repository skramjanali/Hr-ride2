# HR RIDE V19 — Production Release Hardening

Added:
- Server-side ride status transition validation
- Safer payment configuration template (.env.example)
- Customer/driver lifecycle remains Firestore real-time
- Driver GPS + online/offline flow remains intact

Before publishing to Play Store/App Store:
1. Deploy the backend behind HTTPS.
2. Configure Razorpay credentials only as server environment variables.
3. Configure Google Maps API keys with app restrictions; do not commit keys.
4. Enable Firebase Phone Auth, Firestore, Cloud Messaging and required billing/project settings.
5. Add iOS Firebase/Google Maps configuration in the iOS Runner project.
6. Replace demo `http://10.0.2.2:8080` with your deployed HTTPS API URL.
7. Test OTP, booking, driver acceptance, GPS, cancellation, completion and payment verification on real devices.

This package is source/release-ready scaffolding, not a claim of deployed production infrastructure.
