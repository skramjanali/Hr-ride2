
# HR RIDE V14 — Driver Matching + Live Ride

This version continues V13 and adds a working demo backend for:
- Driver online/offline registration
- Driver GPS location updates
- Nearest-online-driver matching when a ride is created with pickup coordinates
- Ride lifecycle status API
- Customer live ride screen polling the backend every 3 seconds
- Nearby-driver API

## Run backend
Requires Node.js:
```bash
cd backend
npm install
npm start
```
Default server: `http://YOUR_SERVER_IP:8080`

## Flutter backend URL
For an Android emulator, use `http://10.0.2.2:8080`.
For a real phone, use the computer/server LAN IP, e.g. `http://192.168.1.10:8080`.

The Flutter app does NOT contain the Google Maps API key in this ZIP. Keep the key restricted in Google Cloud and place it only in the platform configuration.

## Important
This is a development/demo matching backend. Production needs:
- Firebase/Firestore or another persistent database
- authenticated driver/customer IDs
- secure server deployment (HTTPS)
- server-side authorization
- production-grade location/background tracking
- push notifications
- real payment gateway + server-side order/signature verification
