# HR RIDE V13 — Google Maps + GPS

This version adds a real Google Maps screen and device GPS location stream to the existing Firebase OTP app.

## Google Cloud
Enable: Maps SDK for Android, Maps SDK for iOS, Places API (New). For route ETA/directions, also enable Routes API.

## API key
The project intentionally does NOT store a shared API key in source control. In `android/app/build.gradle`, replace `YOUR_GOOGLE_MAPS_API_KEY` with your Android-restricted key. Use package `com.hrride.app`.

For iPhone, add the iOS Maps key in the generated iOS Runner/AppDelegate configuration when the iOS platform folder is created.

## Android GPS
Location permissions are already added. The app asks for permission when the Live GPS screen opens.

## What is live now
- Google Map display
- Current device GPS marker
- GPS stream updates
- Customer/Driver can open the map from their screens

## Still requires backend/deployment
Driver matching, multi-user live driver location sharing, real ETA, push notifications and production ride state synchronization need a deployed backend/Firestore rules/cloud functions. This package does not claim those are live yet.
