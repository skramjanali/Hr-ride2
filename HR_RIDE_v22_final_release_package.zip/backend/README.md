# HR RIDE Backend Demo

## Run
npm install
npm start

Health: GET /health
Create ride: POST /rides
Get ride: GET /rides/:id
Update status: PATCH /rides/:id/status

This is a development backend only. For production, add authentication,
persistent database, rate limiting, validation, HTTPS, audit logging and
secure payment/webhook handling.
