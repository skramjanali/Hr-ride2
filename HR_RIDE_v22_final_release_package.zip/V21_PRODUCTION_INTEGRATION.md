# HR RIDE V21 — Production Integration

V21 continues from V20 and focuses on wiring the remaining production integrations without embedding private secrets.

## Included
- Production integration checklist
- Firebase Auth / Firestore / FCM configuration notes
- Google Maps key placeholder and restriction notes
- Razorpay server-side payment requirements
- HTTPS backend configuration
- Android release checklist
- iPhone release checklist
- End-to-end ride lifecycle test matrix

## Ride lifecycle
requested -> assigned -> arriving -> started -> completed
Cancellation is allowed only in the states supported by the app/backend state machine.

## Required account-side setup
1. Firebase Phone Authentication enabled.
2. Firestore rules reviewed and deployed.
3. Firebase Cloud Messaging configured.
4. Google Maps SDK for Android/iOS enabled and restricted keys configured.
5. Routes API enabled if route/ETA features are used.
6. Production HTTPS backend deployed.
7. Razorpay production/test keys configured ONLY on the server.
8. Server-side Razorpay order creation and signature verification enabled.
9. Webhooks configured where required.
10. Android and iOS signing configured.

## Secrets
Never put these in Dart source or commit them to Git:
- Razorpay key secret
- Firebase service-account private key
- unrestricted Google API keys

The Android Maps API key remains a build-time placeholder.

## Release testing
Customer:
- OTP login
- Select AC/Non-AC
- Enter pickup/drop
- Create ride
- See driver assignment
- Live tracking
- Cancel when permitted
- Complete ride/payment

Driver:
- OTP/login
- Go online
- GPS permission
- Receive requested ride
- Accept
- Arriving
- Start
- Complete
- Go offline

Admin:
- See live driver count
- See active ride count
- Monitor ride states

## Important
This ZIP is source code/configuration scaffolding. It does not deploy Firebase, Google Cloud, Razorpay, a production backend, Play Store, or App Store.
