# HR RIDE Offline Demo

The customer booking screen now demonstrates:
1. Enter destination
2. Book ride
3. Driver assigned
4. Driver arriving
5. Start ride
6. Complete ride

No real GPS, driver matching, payment or network calls are performed.
Those require production services.
